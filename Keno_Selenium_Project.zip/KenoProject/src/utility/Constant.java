package utility;

public class Constant {

	public static final String URL= "https://www.keno.com.au";
	public static final String UserName ="admin";
    public static final String Password = "admin1";
    public static final String Path_Testdata="C://SamtaSelenium//";
    public static final String File_TestData ="TestData3.xlsx";
    public static final String exepath= "C:\\SamtaSelenium\\chromedriver_win32\\chromedriver.exe";


	}


