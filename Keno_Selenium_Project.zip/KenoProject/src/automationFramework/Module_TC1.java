package automationFramework;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
//import com.sun.org.apache.bcel.internal.generic.Select;
import org.openqa.selenium.support.ui.Select;



import utility.Constant;
import appModule.Find_Venue;
import appModule.Check_Result;
import appModule.Game_Guide;
import appModule.Check_Result_Camb;
import appModule.Winner;


public class Module_TC1 {

	public static ChromeDriver driver= null;
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		String exepath= "C:\\SamtaSelenium\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exepath);
		
		
		//System.setProperty("java.net.preferIPv4Stack" , "true");
		
		 driver= new ChromeDriver();
		
		//WebDriver driver=new FirefoxDriver();
		
		// Access the Website
		//driver.get("https://keno.com.au?jurisdiction=VIC");
		driver.get("https://www.keno.com.au?jurisdiction=VIC");
		Thread.sleep(5000);
	    
		// Maximize Browser Window
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    
	    // Find the Venue in Pub
	    Find_Venue.Find_Venu_Process(driver);
	     Find_Venue.Find_Venue_List(driver); 
	     driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	     
	    
	    //Check Result for Camberwell Location
	    Check_Result_Camb.Find_Venu_Process(driver);
	    driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	    
	    //Find the Winner in Game
	    driver.get("https://www.keno.com.au?jurisdiction=VIC");
	    Winner.Winner_Process(driver);
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    
	  //Check Result
	    Check_Result.Check_Result1(driver);
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    
	    //Find the Game Guide
	    driver.get("https://www.keno.com.au/games/classic");
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    Game_Guide.Game_Guide_Process(driver); 
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    
	 // Scrolling the web page is not required for this test. Can be skipped by commenting it out.
	 		//JavascriptExecutor jse = (JavascriptExecutor)driver;
	 		//jse.executeScript("window.scrollBy(0,500)", "");
	     
	   // WebElement findYourLocal= driver.findElement(By.xpath("//p//a[@ui-sref='venue-finder']"));
	    
	    //Actions action = new Actions(driver);
		//action.sendKeys(Keys.ESCAPE).build().perform();
		
		//findYourLocal.click();
		
	 		
	    driver.quit();
	}

}


